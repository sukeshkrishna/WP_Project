<?php
include 'connection.php';
/*include 'PHPExcel/IOFactory.php';
include_path "C:\xampp\php\PEAR"; */
/*require_once 'PHPExcel-1.8/Classes/PHPExcel.php';*/
include 'IOFactory.php';
session_start();
$urn=$_SESSION['username'];
$sub=$_SESSION['sub'];
$sem=$_SESSION['sem'];
if(isset($_POST["upload"])) { 
//delete the previous row values from stud_marks database table
mysqli_query($dbhandle,"DELETE FROM `studtab1` WHERE `Tuser`='$urn' AND `Subject`='$sub'") or die(mysqli_error($dbhandle));
/*move_uploaded_file($_FILES["file"]["tmp_name"],
"upload/" . $_FILES["file"]["name"]);*/
//Open excel file
$objPHPExcel=PHPExcel_IOFactory::load($_FILES["file"]["tmp_name"]);
foreach ($objPHPExcel->getWorksheetIterator() as $worksheet)
{
    $highestRow=$worksheet->getHighestRow();
    for($row=2;$row<=$highestRow;$row++)
    {
        $name=mysqli_real_escape_string($dbhandle,$worksheet->getCellByColumnAndRow(0,$row)->getValue());
        $usn=mysqli_real_escape_string($dbhandle,$worksheet->getCellByColumnAndRow(1,$row)->getValue());
        $cie1=mysqli_real_escape_string($dbhandle,$worksheet->getCellByColumnAndRow(2,$row)->getValue());
		$cie2=mysqli_real_escape_string($dbhandle,$worksheet->getCellByColumnAndRow(3,$row)->getValue());
		$cie3=mysqli_real_escape_string($dbhandle,$worksheet->getCellByColumnAndRow(4,$row)->getValue());
		$quiz=mysqli_real_escape_string($dbhandle,$worksheet->getCellByColumnAndRow(5,$row)->getValue());
		$lab=mysqli_real_escape_string($dbhandle,$worksheet->getCellByColumnAndRow(6,$row)->getValue());
		$sstud=mysqli_real_escape_string($dbhandle,$worksheet->getCellByColumnAndRow(7,$row)->getValue());
		$attendance=mysqli_real_escape_string($dbhandle,$worksheet->getCellByColumnAndRow(8,$row)->getValue());
		$sub=mysqli_real_escape_string($dbhandle,$sub);
		$urn=mysqli_real_escape_string($dbhandle,$urn);
		$sem=mysqli_real_escape_string($dbhandle,$sem);
if ($cie1>$cie3 && $cie2>$cie3)
{
          $total=$lab+$quiz+$sstud+$cie1+$cie2;
 }
else
if ($cie2>$cie1 && $cie3>$cie1)
    { 
		$total=$lab+$quiz+$sstud+$cie3+$cie2;
	}

else
    { 
		$total=$lab+$quiz+$sstud+$cie3+$cie1;
	}
if($total<20 || $attendance<85)
	$elg="No";
else
	$elg="Yes";
echo $total;
       $total=mysqli_real_escape_string($dbhandle,$total);
	   $elg=mysqli_real_escape_string($dbhandle,$elg);
$query="INSERT INTO `studtab1`(`Name`,`USN`,`Sem`,`Subject`,`CIE1`,`CIE2`,`CIE3`,`Lab`,`Quiz`,`SStudy`,`Attendance`,`Total`,`Eligiblity`,`Tuser`) VALUES ('$name','$usn', '$sem','$sub','$cie1','$cie2','$cie3','$lab','$quiz','$sstud','$attendance','$total','$elg','$urn')";
     mysqli_query($dbhandle,$query ) or die(mysqli_error($dbhandle));
	 echo "Data stored<br>";
    }
	break;
   }
}
?>
<!--,`USN`,`Sem`,`Subject`,`CIE1`,`CIE2`,`CIE3`,`Lab`,`Quiz`,`SStudy`,`Attendance`,`Total`,`Eligiblity`,`Tuser`  , '$usn', '$sem','$sub','$cie1','$cie2','$cie3','$lab','$quiz','$sstud','$attendance','$total','$elg','$urn'-->