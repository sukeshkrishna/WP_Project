<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Admin Login</title>
<script type="text/javascript">
var oldtop="<?php
include 'connection.php';
$query = 'SELECT * FROM `tlist1`';    //idk syntax

$result = mysqli_query($dbhandle,$query);

while($arry = mysqli_fetch_array($result)){
	if($arry['Username']=='admin')
	continue;
	else
	break;}
echo $arry['Name'];
?>";
function selitem(sitem){
dom=document.getElementById(sitem).className='selected-item';
com=document.getElementById(oldtop);
//com.class=undefined;
oldtop=sitem;
}
</script>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("#addrows").click(function(){
		alert("hhh");
         $('#tab > tbody:last-child').append(" <tr><td><input type=\"text\" /></td><td><input type=\"text\" /></td><td><input type=\"text\" /></td></tr>");
    });
//});
</script>-->
<script type="text/javascript">
var count=1;
function add(){
dom=document.getElementById("tab").innerHTML;
com=dom.insertRow(count);
cell1=com.insertCell(0);
cell2=com.insertCell(1);
cell3=com.insertCell(2);
cell1.innerHTML='<input type="text"/>';
cell2.innerHTML='<input type="text"/>';
cell3.innerHTML='<input type="text"/>';
}
</script>
<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
<link href="studin.css" rel="stylesheet" type="text/css">
</head>

<body>
		

		<section id="body" class="width">
			<aside id="sidebar" class="column-left">

			<header><img src="BMS_College_of_Engineering_20.png" width="207" height="205" alt=""/>			</header>

			<nav id="mainnav">
  				<ul>
				<?php
include 'connection.php';
$query = "SELECT * FROM `tlist1`";    //idk syntax
  
$result = mysqli_query($dbhandle,$query);

while($arry = mysqli_fetch_array($result)) {
	if($arry['Name']=='admin')
			continue;
	echo "<li onclick=\"selitem('".$arry['Username']."');\" id=\"".$arry['Username']."\"><a href=\"Adminlog1.php?name=".$arry['Username']."\">".$arry['Username']."</a></li>"  ;  
	}
?>
                            		
  				</ul><br><br>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="Addteacher.html" class="button-reversed" align="center">Add Teacher </a>
			</nav>

			
			
			</aside>
			<section id="content" class="column-right">
               		
                		
	    <article>
	      <h2 align="center">BMSCE MARKS AND ATTENDANCE<br>
          </h2>   <a href="logout.php" class="button" style="float:right;">Logout</a><br><br>
	      <table  border="5" cellpadding="5" cellspacing="5" id="tab">
	        <tbody>
	          <tr>
	            <th width="34" scope="col">Course</th>
				<th width="34" scope="col">Course Code </th>
	            <th width="34" scope="col">Semester </th>
	          </tr>
			  <?php 
			  include 'connection.php';
			  session_start();
			  $sub=$_GET['name'];
			  $_SESSION['var']=$sub;
			  $query = "SELECT * FROM `tlist2` WHERE `Name`='$sub'";
			 
			 $result = mysqli_query($dbhandle,$query);
			 while($arry = mysqli_fetch_array($result)) {
				 echo '<tr>' . '<td>' . $arry['Course'] .'</td>'. '<td>' . $arry['Ccode'] . '</td>'  . '<td>' . $arry['Sem'] . '</td>'.'</tr>' ;
				 } 
			  echo '</tbody>';
				 ?> 
	
			</tbody>
			
		    </table>
<div class="body"></div>
		<div class="grad"></div>
		<div class="header">
          <color-profile> </color-profile>
		</div>
		<br>
		<a href="Addcourse.php" class="button"> Add Course<a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<!--<button class="button-reversed"> Edit </button>-->


<br/>
 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp;  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;
		.
		&nbsp;&nbsp;
		&nbsp;<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
		&nbsp; </article>
<footer class="clear">
	  <p>Thank for using our site!!!!</p>
	  <p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p>
			</footer>

		</section>

		<div class="clear"></div>

	</section>
	
	

</body>
</html>

<!--<li class="selected-item"><a href="#">Teacher 1</a></li>-->
<!--width="1210" height="413"-->