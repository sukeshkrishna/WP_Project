
<?php // login.php
include 'openid.php';
$openid = new LightOpenID("localhost");

if ($openid->mode) {
    if ($openid->mode == 'cancel') {
		header('Location: studloggoogle.php');
    } elseif($openid->validate()) {
        $data = $openid->getAttributes();
        $email = $data['contact/email'];
        $first = $data['namePerson/first'];
		$usn = substr($email,-12);
		$result=mysqli_query($dbhandle,"SELECT * FROM `studtab1` WHERE `USN`='$usn'") or die("Invalid User!");
		session_start();
		$_SESSION['usn']=$usn;
		header('Location: studgin.php?usn='.$usn);
        echo "Identity: $openid->identity <br>";
        echo "Email: $email <br>";
        echo "First name: $first";
    } else {
        echo "The user has not logged in";
    }
} else {
    echo "Go to index page to log in.";
}
?>
<!--1bm16cs047@bmsce.ac.in-->

<!--Client ID      663334043637-hlb9ocmbb6en5n33qjt2vvneildktmv7.apps.googleusercontent.com     -->
<!--Client Secret    ESFJEWKaPdiOIFjrg2RYg3iy    -->