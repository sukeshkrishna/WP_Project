<?php
include 'connection.php';

$myusername = $_POST['username'];
$mypassword = $_POST['password'];

/*$myusername = stripslashes($myusername);
$myusername = stripslashes($myusername);*/
$query = "SELECT * FROM `tlist1` WHERE Username='$myusername' AND Password='$mypassword'";
$result=mysqli_query($dbhandle,$query);
$count= mysqli_num_rows($result);

/*mysqli_close(NULL);*/
	
if($count==1){
	if($myusername=='admin' && $mypassword=='admin123')
{
	$seconds=300+time();
	session_start();
	header("location:Adminlog1.php?name=");
} 
else{
	$seconds=300+time();
	session_start();
    $_SESSION['username']=$myusername;
	header("location:Teachin3.php?sub=");
}
}
else {
	echo 'Incorrect Username or Password';
}
?>