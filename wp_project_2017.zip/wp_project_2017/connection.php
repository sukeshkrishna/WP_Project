<?php
$username = "Medhini";
$password = "medhini";
$hostname = "localhost";

$dbhandle = mysqli_connect($hostname,$username,$password,'medhini') or die("Could not connect to data base");
//$connected=mysqli_select_db($dbhandle,) or die ("Problem");

?>