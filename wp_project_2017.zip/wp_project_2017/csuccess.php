<?php
include 'connection.php';
session_start();
$var=$_SESSION['var'];
$name = $_POST['course'];
$username = $_POST['ccode'];
$pass = $_POST['sem'];

if(!$_POST['submit']){
echo "Please fill out the form";
header('Location: Addcourse.php');
} else {
	mysqli_query($dbhandle,"INSERT INTO `tlist2`(`Name`,`Course`, `Ccode`, `Sem`) 
	VALUES ('$var','$name','$username','$pass')") or die(mysqli_error($dbhandle));
	echo "User has been Registered";
	header('Location: Adminlog1.php?name=');
}

?>